# Threat Investigations QR Landing Page

Upload `index.html` to any simple web host such as Netlify, GitHub Pages, Cloudflare Pages, or your own domain.

Then create a QR code pointing to that page URL.

Recommended QR export for the coin manufacturer:
- SVG or EPS if available
- Otherwise high-resolution PNG
